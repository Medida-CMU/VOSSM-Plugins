scimapClient
============

This R package collects information about what other packages are installed and what
their dependencies are, and submits them to a server where users and package authors
can monitor usage trends. 

The server software is [scisoft-net-map](https://github.com/cbogart/scisoft-net-map).

